# Energy Consumption Prediction Project

This project predicts daily energy consumption based on temperature data.

## Project Structure
- `data/` : Contains dataset files
- `notebooks/` : Jupyter notebooks for analysis
- `src/` : Python modules for preprocessing, model training, prediction, and visualization
- `main.py` : Entry script to run the complete process

## Usage
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the project:
   ```bash
   python main.py
   ```

## Author
Created for energy prediction analysis.
